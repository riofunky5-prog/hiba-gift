"use client";

import { useEffect, useRef, useState } from "react";
import gsap from "gsap";

export interface BloomState {
  stem: number; // 0 -> 1, stem growing from the ground
  petals: number; // 0 -> 1, petals unfurling
  sway: number; // -1 -> 1, wind sway
  done: boolean;
}

/**
 * Drives the rose growth timeline once `active` becomes true:
 * stem rises first, then petals unfurl, then a gentle infinite wind sway
 * begins. Returns plain numbers so the R3F scene can stay a normal
 * function component (no gsap refs on meshes needed).
 */
export function useBloomTimeline(active: boolean) {
  const [state, setState] = useState<BloomState>({
    stem: 0,
    petals: 0,
    sway: 0,
    done: false,
  });
  const startedRef = useRef(false);

  useEffect(() => {
    if (!active || startedRef.current) return;
    startedRef.current = true;

    const values = { stem: 0, petals: 0 };
    const tl = gsap.timeline();

    tl.to(values, {
      stem: 1,
      duration: 2.2,
      ease: "power2.out",
      onUpdate: () =>
        setState((s) => ({ ...s, stem: values.stem })),
    }).to(values, {
      petals: 1,
      duration: 2.6,
      ease: "power3.out",
      onUpdate: () =>
        setState((s) => ({ ...s, petals: values.petals })),
      onComplete: () => setState((s) => ({ ...s, done: true })),
    });

    let raf: number;
    const windStart = performance.now();
    function windLoop(now: number) {
      const t = (now - windStart) / 1000;
      setState((s) => ({ ...s, sway: Math.sin(t * 0.6) }));
      raf = requestAnimationFrame(windLoop);
    }
    raf = requestAnimationFrame(windLoop);

    return () => {
      tl.kill();
      cancelAnimationFrame(raf);
    };
  }, [active]);

  return state;
}
