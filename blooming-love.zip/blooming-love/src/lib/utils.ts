import clsx, { type ClassValue } from "clsx";

/** Merge conditional class names. */
export function cn(...inputs: ClassValue[]) {
  return clsx(...inputs);
}

/** Pads a number to at least two digits, e.g. 4 -> "04". */
export function pad2(value: number) {
  return value.toString().padStart(2, "0");
}

export interface Elapsed {
  days: number;
  hours: number;
  minutes: number;
  seconds: number;
}

/** Elapsed time breakdown between a start date and now. */
export function getElapsed(start: Date, now: Date = new Date()): Elapsed {
  const diff = Math.max(0, now.getTime() - start.getTime());
  const seconds = Math.floor(diff / 1000) % 60;
  const minutes = Math.floor(diff / (1000 * 60)) % 60;
  const hours = Math.floor(diff / (1000 * 60 * 60)) % 24;
  const days = Math.floor(diff / (1000 * 60 * 60 * 24));
  return { days, hours, minutes, seconds };
}

/** Deterministic pseudo-random generator so SSR and client render match. */
export function seededRandom(seed: number) {
  let value = seed;
  return () => {
    value = (value * 9301 + 49297) % 233280;
    return value / 233280;
  };
}
