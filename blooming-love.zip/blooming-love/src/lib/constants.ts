import type { GalleryImage, TimelineEvent } from "@/types";

/**
 * The date the story began. Edit this to the real date — the Love Counter
 * on the page counts every second onward from this moment.
 */
export const LOVE_START_DATE = new Date("2023-01-01T00:00:00");

export const SITE = {
  name: "Blooming Love",
  heroTitle: "For Hiba",
  heroSubtitleLines: [
    "Every flower blooms one day...",
    "Meeting you made my heart bloom.",
  ],
  ctaLabel: "Open My Heart",
};

export const LOVE_LETTER = {
  salutation: "Dear Hiba,",
  paragraphs: [
    "You changed my world.",
    "Every smile, every laugh, every moment with you became a memory I never want to lose.",
    "Thank you for existing.",
  ],
  signOff: ["I love you.", "Forever."],
};

export const FINAL_MESSAGE = "I will always choose you.";

/**
 * Replace these with real photos. Drop files into /public/images and
 * update the src paths + captions below. Nothing here is a stock photo —
 * these are just the slots waiting for your memories.
 */
export const GALLERY_IMAGES: GalleryImage[] = [
  {
    id: "memory-01",
    src: "/images/memory-1.jpg",
    alt: "A cherished memory with Hiba",
    caption: "The first time you laughed at one of my terrible jokes.",
  },
  {
    id: "memory-02",
    src: "/images/memory-2.jpg",
    alt: "A cherished memory with Hiba",
    caption: "That evening the sky matched how I felt.",
  },
  {
    id: "memory-03",
    src: "/images/memory-3.jpg",
    alt: "A cherished memory with Hiba",
    caption: "Quiet moments, the ones I keep closest.",
  },
  {
    id: "memory-04",
    src: "/images/memory-4.jpg",
    alt: "A cherished memory with Hiba",
    caption: "You, mid-laugh, unaware how much I was staring.",
  },
  {
    id: "memory-05",
    src: "/images/memory-5.jpg",
    alt: "A cherished memory with Hiba",
    caption: "A day I never wanted to end.",
  },
  {
    id: "memory-06",
    src: "/images/memory-6.jpg",
    alt: "A cherished memory with Hiba",
    caption: "Every detail of this one, still vivid.",
  },
];

/**
 * Edit freely — add, remove, or reorder chapters of your story.
 */
export const TIMELINE_EVENTS: TimelineEvent[] = [
  {
    id: "chapter-01",
    date: "The Beginning",
    title: "The First Hello",
    description:
      "A conversation that should have been ordinary, and wasn't. I knew within minutes you were different.",
    icon: "sparkle",
  },
  {
    id: "chapter-02",
    date: "Weeks Later",
    title: "The First Laugh Together",
    description:
      "The moment the nerves disappeared and it just felt easy — like we'd known each other for years.",
    icon: "star",
  },
  {
    id: "chapter-03",
    date: "That Season",
    title: "The Day Everything Changed",
    description:
      "I stopped counting the days since we met and started counting the days I got to spend with you.",
    icon: "flower",
  },
  {
    id: "chapter-04",
    date: "Since Then",
    title: "Every Ordinary Day",
    description:
      "Made extraordinary, simply because you were in it. Still true. Still counting.",
    icon: "heart",
  },
  {
    id: "chapter-05",
    date: "Always",
    title: "What Comes Next",
    description:
      "Every chapter still unwritten, I want to write with you.",
    icon: "ring",
  },
];

export const AMBIENT_TRACK = {
  src: "/music/music.mp3",
  title: "Our Song",
};
