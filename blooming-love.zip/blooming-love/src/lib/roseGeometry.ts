import * as THREE from "three";

/**
 * A single rose petal as an extruded 2D shape: a rounded, slightly
 * asymmetric teardrop, which reads as a petal silhouette once curved
 * and layered in 3D.
 */
export function createPetalGeometry(): THREE.ExtrudeGeometry {
  const shape = new THREE.Shape();
  shape.moveTo(0, 0);
  shape.bezierCurveTo(0.55, 0.15, 0.62, 0.95, 0, 1.55);
  shape.bezierCurveTo(-0.62, 0.95, -0.55, 0.15, 0, 0);

  const geometry = new THREE.ExtrudeGeometry(shape, {
    depth: 0.02,
    bevelEnabled: true,
    bevelThickness: 0.01,
    bevelSize: 0.02,
    bevelSegments: 2,
    curveSegments: 12,
  });

  geometry.translate(0, 0, -0.01);
  geometry.computeVertexNormals();
  return geometry;
}

/** A simple pointed leaf shape for the stem. */
export function createLeafGeometry(): THREE.ExtrudeGeometry {
  const shape = new THREE.Shape();
  shape.moveTo(0, 0);
  shape.quadraticCurveTo(0.4, 0.5, 0, 1.3);
  shape.quadraticCurveTo(-0.4, 0.5, 0, 0);

  const geometry = new THREE.ExtrudeGeometry(shape, {
    depth: 0.015,
    bevelEnabled: false,
    curveSegments: 8,
  });
  geometry.translate(0, 0, -0.0075);
  geometry.computeVertexNormals();
  return geometry;
}

export interface PetalLayout {
  layer: number;
  angle: number;
  scale: number;
  tilt: number;
  radius: number;
}

/**
 * Builds the layout for every petal in the bloom: inner layers are small,
 * upright, and tightly packed (the bud); outer layers are larger, more
 * horizontal, and more numerous (the open bloom).
 */
export function buildPetalLayout(): PetalLayout[] {
  const layers = [
    { count: 5, scale: 0.42, tilt: 0.35, radius: 0.05 },
    { count: 6, scale: 0.6, tilt: 0.6, radius: 0.09 },
    { count: 7, scale: 0.8, tilt: 0.95, radius: 0.14 },
    { count: 8, scale: 1.0, tilt: 1.3, radius: 0.2 },
    { count: 9, scale: 1.15, tilt: 1.55, radius: 0.26 },
  ];

  const layout: PetalLayout[] = [];
  layers.forEach((layer, layerIndex) => {
    const angleStep = (Math.PI * 2) / layer.count;
    const angleOffset = layerIndex % 2 === 0 ? 0 : angleStep / 2;
    for (let i = 0; i < layer.count; i++) {
      layout.push({
        layer: layerIndex,
        angle: angleOffset + angleStep * i,
        scale: layer.scale,
        tilt: layer.tilt,
        radius: layer.radius,
      });
    }
  });

  return layout;
}
