export interface GalleryImage {
  id: string;
  src: string;
  alt: string;
  caption?: string;
}

export interface TimelineEvent {
  id: string;
  date: string;
  title: string;
  description: string;
  icon: "heart" | "star" | "flower" | "moon" | "ring" | "sparkle";
}

export interface AudioTrack {
  src: string;
  title: string;
}
