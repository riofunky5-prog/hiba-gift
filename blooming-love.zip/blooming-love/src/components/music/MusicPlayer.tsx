"use client";

import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Play, Pause, Volume2, Volume1, VolumeX } from "lucide-react";
import { useAmbientAudio } from "@/components/providers/AudioProvider";
import { AMBIENT_TRACK } from "@/lib/constants";

export default function MusicPlayer() {
  const { isPlaying, volume, toggle, setVolume } = useAmbientAudio();
  const [expanded, setExpanded] = useState(false);

  const VolumeIcon = volume === 0 ? VolumeX : volume < 0.5 ? Volume1 : Volume2;

  return (
    <div className="fixed bottom-6 right-6 z-50 flex flex-col items-end gap-3 sm:bottom-8 sm:right-8">
      <AnimatePresence>
        {expanded && (
          <motion.div
            initial={{ opacity: 0, y: 10, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 10, scale: 0.95 }}
            transition={{ duration: 0.25 }}
            className="flex items-center gap-3 rounded-full border border-gold/25 bg-black/40 px-4 py-3 backdrop-blur-xl"
          >
            <VolumeIcon size={16} className="text-gold" />
            <input
              type="range"
              min={0}
              max={1}
              step={0.01}
              value={volume}
              onChange={(e) => setVolume(parseFloat(e.target.value))}
              className="h-1 w-24 cursor-pointer appearance-none rounded-full bg-gold/25 accent-gold"
              aria-label="Volume"
            />
          </motion.div>
        )}
      </AnimatePresence>

      <div className="flex items-center gap-3 rounded-full border border-gold/25 bg-black/40 px-4 py-3 backdrop-blur-xl shadow-gold">
        <button
          aria-label={isPlaying ? "Pause" : "Play"}
          onClick={toggle}
          className="flex h-9 w-9 items-center justify-center rounded-full bg-gold text-black transition-transform hover:scale-105"
        >
          {isPlaying ? <Pause size={15} /> : <Play size={15} />}
        </button>

        <button
          onClick={() => setExpanded((v) => !v)}
          className="flex flex-col items-start pr-1 text-left"
        >
          <span className="max-w-[9rem] truncate font-body text-xs text-ivory">
            {AMBIENT_TRACK.title}
          </span>
          <span className="font-body text-[10px] uppercase tracking-[0.2em] text-gold/70">
            {isPlaying ? "Now playing" : "Paused"}
          </span>
        </button>
      </div>
    </div>
  );
}
