"use client";

import { type ButtonHTMLAttributes } from "react";
import { motion } from "framer-motion";
import { cn } from "@/lib/utils";

interface GlowButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  label: string;
}

export default function GlowButton({
  label,
  className,
  ...props
}: GlowButtonProps) {
  return (
    <motion.button
      whileHover={{ scale: 1.04 }}
      whileTap={{ scale: 0.97 }}
      className={cn(
        "group relative inline-flex items-center justify-center overflow-hidden rounded-full border border-gold/50 bg-gradient-to-b from-white/[0.06] to-transparent px-10 py-4 font-body text-sm uppercase tracking-[0.28em] text-ivory shadow-gold transition-shadow duration-500 hover:shadow-gold-lg",
        "animate-pulse-glow",
        className
      )}
      {...props}
    >
      <span className="absolute inset-0 -translate-x-full bg-gradient-to-r from-transparent via-white/25 to-transparent transition-transform duration-700 ease-out group-hover:translate-x-full" />
      <span className="relative">{label}</span>
    </motion.button>
  );
}
