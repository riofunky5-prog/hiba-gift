"use client";

import { useState } from "react";
import Image from "next/image";
import { motion } from "framer-motion";
import Lightbox from "@/components/gallery/Lightbox";
import { GALLERY_IMAGES } from "@/lib/constants";

export default function Gallery() {
  const [activeIndex, setActiveIndex] = useState<number | null>(null);

  return (
    <section
      id="gallery-section"
      className="relative w-full bg-void px-6 py-28 sm:px-10"
    >
      <div className="mx-auto max-w-6xl">
        <motion.h2
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.9 }}
          className="mb-3 text-center font-display text-4xl italic text-ivory sm:text-5xl"
        >
          Moments I keep
        </motion.h2>
        <p className="mx-auto mb-16 max-w-md text-center font-body text-sm text-ivory-dim">
          Replace these with your own photos in{" "}
          <code className="rounded bg-white/10 px-1.5 py-0.5 text-gold">
            /public/images
          </code>
          .
        </p>

        <div className="grid grid-cols-1 gap-8 sm:grid-cols-2 lg:grid-cols-3">
          {GALLERY_IMAGES.map((image, index) => (
            <motion.button
              key={image.id}
              onClick={() => setActiveIndex(index)}
              initial={{ opacity: 0, y: 40 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-60px" }}
              transition={{ duration: 0.7, delay: (index % 3) * 0.12 }}
              animate={{ y: [0, -10, 0] }}
              style={{
                animationDelay: `${index * 0.4}s`,
              }}
              className="group relative aspect-[4/5] overflow-hidden rounded-3xl border border-white/10 bg-white/[0.04] p-2 text-left shadow-[0_20px_60px_-20px_rgba(0,0,0,0.6)] backdrop-blur-md transition-transform duration-500 hover:-translate-y-2 hover:border-gold/40"
            >
              <div className="relative h-full w-full overflow-hidden rounded-2xl">
                <Image
                  src={image.src}
                  alt={image.alt}
                  fill
                  sizes="(max-width: 768px) 90vw, 33vw"
                  className="object-cover transition-transform duration-700 ease-out group-hover:scale-110"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-transparent to-transparent opacity-0 transition-opacity duration-500 group-hover:opacity-100" />
                {image.caption && (
                  <p className="absolute bottom-4 left-4 right-4 translate-y-3 font-script text-sm italic text-ivory opacity-0 transition-all duration-500 group-hover:translate-y-0 group-hover:opacity-100">
                    {image.caption}
                  </p>
                )}
              </div>
            </motion.button>
          ))}
        </div>
      </div>

      <Lightbox
        images={GALLERY_IMAGES}
        activeIndex={activeIndex}
        onClose={() => setActiveIndex(null)}
        onNavigate={setActiveIndex}
      />
    </section>
  );
}
