"use client";

import Image from "next/image";
import { AnimatePresence, motion } from "framer-motion";
import { X, ChevronLeft, ChevronRight } from "lucide-react";
import type { GalleryImage } from "@/types";

interface LightboxProps {
  images: GalleryImage[];
  activeIndex: number | null;
  onClose: () => void;
  onNavigate: (index: number) => void;
}

export default function Lightbox({
  images,
  activeIndex,
  onClose,
  onNavigate,
}: LightboxProps) {
  const image = activeIndex !== null ? images[activeIndex] : null;

  function goto(delta: number) {
    if (activeIndex === null) return;
    const next = (activeIndex + delta + images.length) % images.length;
    onNavigate(next);
  }

  return (
    <AnimatePresence>
      {image && (
        <motion.div
          className="fixed inset-0 z-[80] flex items-center justify-center bg-black/90 p-6 backdrop-blur-lg"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={onClose}
        >
          <button
            aria-label="Close"
            onClick={onClose}
            className="absolute right-6 top-6 flex h-11 w-11 items-center justify-center rounded-full border border-gold/40 text-gold hover:text-gold-bright"
          >
            <X size={20} />
          </button>

          <button
            aria-label="Previous image"
            onClick={(e) => {
              e.stopPropagation();
              goto(-1);
            }}
            className="absolute left-4 top-1/2 flex h-11 w-11 -translate-y-1/2 items-center justify-center rounded-full border border-gold/40 text-gold hover:text-gold-bright sm:left-8"
          >
            <ChevronLeft size={22} />
          </button>

          <button
            aria-label="Next image"
            onClick={(e) => {
              e.stopPropagation();
              goto(1);
            }}
            className="absolute right-4 top-1/2 flex h-11 w-11 -translate-y-1/2 items-center justify-center rounded-full border border-gold/40 text-gold hover:text-gold-bright sm:right-8"
          >
            <ChevronRight size={22} />
          </button>

          <motion.div
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0.95, opacity: 0 }}
            transition={{ duration: 0.35, ease: [0.16, 1, 0.3, 1] }}
            className="relative max-h-[80vh] w-full max-w-3xl overflow-hidden rounded-3xl border border-gold/25"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="relative aspect-[4/5] w-full sm:aspect-[16/10]">
              <Image
                src={image.src}
                alt={image.alt}
                fill
                sizes="(max-width: 768px) 100vw, 768px"
                className="object-cover"
              />
            </div>
            {image.caption && (
              <div className="bg-black/70 p-5 text-center font-script text-lg italic text-ivory">
                {image.caption}
              </div>
            )}
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
