"use client";

import {
  createContext,
  useContext,
  useEffect,
  useRef,
  useState,
  type ReactNode,
} from "react";
import { AMBIENT_TRACK } from "@/lib/constants";

interface AudioContextValue {
  isPlaying: boolean;
  volume: number;
  toggle: () => void;
  setVolume: (v: number) => void;
}

const Ctx = createContext<AudioContextValue | null>(null);

export function AudioProvider({ children }: { children: ReactNode }) {
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [volume, setVolumeState] = useState(0.55);

  useEffect(() => {
    const audio = new Audio(AMBIENT_TRACK.src);
    audio.loop = true;
    audio.volume = volume;
    audioRef.current = audio;
    return () => {
      audio.pause();
      audio.src = "";
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    if (audioRef.current) audioRef.current.volume = volume;
  }, [volume]);

  function toggle() {
    const audio = audioRef.current;
    if (!audio) return;
    if (isPlaying) {
      audio.pause();
      setIsPlaying(false);
    } else {
      audio.play().catch(() => {
        // Autoplay can be blocked until a user gesture — the click itself
        // that called toggle() satisfies that, so this mostly guards
        // against missing /public/music/music.mp3 in dev.
      });
      setIsPlaying(true);
    }
  }

  function setVolume(v: number) {
    setVolumeState(Math.min(1, Math.max(0, v)));
  }

  return (
    <Ctx.Provider value={{ isPlaying, volume, toggle, setVolume }}>
      {children}
    </Ctx.Provider>
  );
}

export function useAmbientAudio() {
  const ctx = useContext(Ctx);
  if (!ctx) {
    throw new Error("useAmbientAudio must be used within AudioProvider");
  }
  return ctx;
}
