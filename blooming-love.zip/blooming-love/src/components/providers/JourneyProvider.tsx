"use client";

import {
  createContext,
  useCallback,
  useContext,
  useState,
  type ReactNode,
} from "react";

interface JourneyContextValue {
  isWarping: boolean;
  hasEntered: boolean;
  beginJourney: () => void;
  endWarp: () => void;
}

const Ctx = createContext<JourneyContextValue | null>(null);

export function JourneyProvider({ children }: { children: ReactNode }) {
  const [isWarping, setIsWarping] = useState(false);
  const [hasEntered, setHasEntered] = useState(false);

  const beginJourney = useCallback(() => {
    setIsWarping(true);
    setHasEntered(true);
  }, []);

  const endWarp = useCallback(() => {
    setIsWarping(false);
  }, []);

  return (
    <Ctx.Provider value={{ isWarping, hasEntered, beginJourney, endWarp }}>
      {children}
    </Ctx.Provider>
  );
}

export function useJourney() {
  const ctx = useContext(Ctx);
  if (!ctx) throw new Error("useJourney must be used within JourneyProvider");
  return ctx;
}
