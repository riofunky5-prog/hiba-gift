"use client";

import { useMemo, useRef } from "react";
import { useFrame } from "@react-three/fiber";
import * as THREE from "three";
import {
  buildPetalLayout,
  createLeafGeometry,
  createPetalGeometry,
} from "@/lib/roseGeometry";
import type { BloomState } from "@/hooks/useBloomTimeline";

const PETAL_LAYOUT = buildPetalLayout();

function Petal({
  layout,
  petalsProgress,
  sway,
}: {
  layout: (typeof PETAL_LAYOUT)[number];
  petalsProgress: number;
  sway: number;
}) {
  const geometry = useMemo(() => createPetalGeometry(), []);
  const ref = useRef<THREE.Mesh>(null);

  // Outer layers open later + wider than inner layers, so the bloom
  // reads as unfurling from the inside out.
  const layerDelay = layout.layer * 0.14;
  const localProgress = THREE.MathUtils.clamp(
    (petalsProgress - layerDelay) / (1 - layerDelay || 1),
    0,
    1
  );
  const eased = THREE.MathUtils.smoothstep(localProgress, 0, 1);

  const closedTilt = -1.35;
  const openTilt = -layout.tilt + 0.5;
  const tilt = THREE.MathUtils.lerp(closedTilt, openTilt, eased);
  const scale = THREE.MathUtils.lerp(0.25, layout.scale, eased) * 0.4;

  useFrame(() => {
    if (!ref.current) return;
    const windInfluence = 0.04 * eased;
    ref.current.rotation.x = tilt + Math.sin(sway * Math.PI) * windInfluence;
    ref.current.rotation.z =
      layout.angle + Math.cos(sway * Math.PI + layout.layer) * windInfluence * 0.5;
    ref.current.scale.setScalar(scale);
  });

  const x = Math.sin(layout.angle) * layout.radius * eased;
  const z = Math.cos(layout.angle) * layout.radius * eased;
  const y = 0.05 + layout.layer * 0.02;

  return (
    <group position={[x, y, z]} rotation={[0, layout.angle, 0]}>
      <mesh ref={ref} geometry={geometry} castShadow receiveShadow>
        <meshStandardMaterial
          color={new THREE.Color("#8f2436")}
          emissive={new THREE.Color("#3a0f16")}
          emissiveIntensity={0.25}
          roughness={0.35}
          metalness={0.05}
          side={THREE.DoubleSide}
        />
      </mesh>
    </group>
  );
}

function Leaf({
  side,
  height,
  stemProgress,
}: {
  side: 1 | -1;
  height: number;
  stemProgress: number;
}) {
  const geometry = useMemo(() => createLeafGeometry(), []);
  const scale = THREE.MathUtils.smoothstep(
    stemProgress - height / 1.6,
    0,
    0.3
  );

  return (
    <group
      position={[0, height, 0]}
      rotation={[0, side === 1 ? 0.4 : Math.PI + 0.4, side * 0.9]}
      scale={scale}
    >
      <mesh geometry={geometry} castShadow>
        <meshStandardMaterial
          color="#1f4d2b"
          roughness={0.6}
          side={THREE.DoubleSide}
        />
      </mesh>
    </group>
  );
}

export default function RoseModel({ bloom }: { bloom: BloomState }) {
  const stemHeight = 2.4 * THREE.MathUtils.smoothstep(bloom.stem, 0, 1);
  const groupRef = useRef<THREE.Group>(null);

  useFrame(() => {
    if (!groupRef.current) return;
    groupRef.current.rotation.z = Math.sin(bloom.sway * Math.PI) * 0.03;
  });

  return (
    <group ref={groupRef} position={[0, -1.4, 0]}>
      {/* stem */}
      <mesh position={[0, stemHeight / 2, 0]} castShadow>
        <cylinderGeometry args={[0.045, 0.06, Math.max(stemHeight, 0.001), 8]} />
        <meshStandardMaterial color="#2b5a34" roughness={0.7} />
      </mesh>

      <Leaf side={1} height={stemHeight * 0.4} stemProgress={bloom.stem} />
      <Leaf side={-1} height={stemHeight * 0.65} stemProgress={bloom.stem} />

      {/* bloom head */}
      <group position={[0, Math.max(stemHeight, 0.15), 0]}>
        {bloom.stem > 0.55 &&
          PETAL_LAYOUT.map((layout, i) => (
            <Petal
              key={i}
              layout={layout}
              petalsProgress={bloom.petals}
              sway={bloom.sway}
            />
          ))}
      </group>
    </group>
  );
}
