"use client";

import { useEffect, useMemo, useState } from "react";
import { motion } from "framer-motion";
import { LOVE_LETTER } from "@/lib/constants";

const FULL_TEXT = [
  LOVE_LETTER.salutation,
  "",
  ...LOVE_LETTER.paragraphs,
  "",
  ...LOVE_LETTER.signOff,
].join("\n");

export default function Letter({ show }: { show: boolean }) {
  const [typedLength, setTypedLength] = useState(0);
  const reduceMotion = useMemo(
    () =>
      typeof window !== "undefined" &&
      window.matchMedia("(prefers-reduced-motion: reduce)").matches,
    []
  );

  useEffect(() => {
    if (!show) return;
    if (reduceMotion) {
      setTypedLength(FULL_TEXT.length);
      return;
    }

    let i = 0;
    const interval = setInterval(() => {
      i += 1;
      setTypedLength(i);
      if (i >= FULL_TEXT.length) clearInterval(interval);
    }, 28);

    return () => clearInterval(interval);
  }, [show, reduceMotion]);

  const visibleText = FULL_TEXT.slice(0, typedLength);
  const lines = visibleText.split("\n");
  const isTyping = typedLength < FULL_TEXT.length;

  return (
    <motion.div
      initial={{ opacity: 0, y: 30 }}
      animate={show ? { opacity: 1, y: 0 } : {}}
      transition={{ duration: 1 }}
      className="mx-auto max-w-xl rounded-[28px] border border-gold/25 bg-white/[0.03] p-8 backdrop-blur-md sm:p-12"
      style={{ minHeight: show ? undefined : 0 }}
    >
      {show && (
        <p className="whitespace-pre-line font-script text-xl italic leading-relaxed text-ivory sm:text-2xl">
          {lines.map((line, idx) => (
            <span key={idx}>
              {line}
              {idx < lines.length - 1 && <br />}
            </span>
          ))}
          {isTyping && (
            <span className="ml-1 inline-block h-5 w-[2px] animate-pulse bg-gold align-middle" />
          )}
        </p>
      )}
    </motion.div>
  );
}
