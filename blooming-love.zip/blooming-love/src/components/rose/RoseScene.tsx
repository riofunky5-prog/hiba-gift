"use client";

import { Suspense } from "react";
import dynamic from "next/dynamic";
import { Canvas } from "@react-three/fiber";
import { Sparkles, ContactShadows, Environment } from "@react-three/drei";
import { motion } from "framer-motion";
import { useInViewport } from "@/hooks/useInViewport";
import { useBloomTimeline } from "@/hooks/useBloomTimeline";
import Letter from "@/components/rose/Letter";

const RoseModel = dynamic(() => import("@/components/rose/RoseModel"), {
  ssr: false,
});

export default function RoseScene() {
  const [ref, inView] = useInViewport<HTMLDivElement>(0.35);
  const bloom = useBloomTimeline(inView);

  return (
    <section
      id="rose-section"
      ref={ref}
      className="relative flex min-h-[180vh] w-full flex-col items-center bg-void py-32"
    >
      <div className="absolute inset-0 bg-gradient-to-b from-void via-void to-wine-deep/20" />

      <motion.h2
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        transition={{ duration: 1 }}
        className="relative z-10 mb-4 text-center font-display text-4xl italic text-ivory sm:text-5xl"
      >
        A rose, for the way you make me feel
      </motion.h2>

      <div className="relative z-10 h-[70vh] w-full max-w-4xl">
        <Canvas
          camera={{ position: [0, 0.4, 4.4], fov: 42 }}
          dpr={[1, 1.75]}
          shadows
        >
          <color attach="background" args={["#05050a"]} />
          <ambientLight intensity={0.35} />
          <directionalLight
            position={[3, 5, 2]}
            intensity={1.4}
            color="#f1d9a8"
            castShadow
          />
          <pointLight position={[-3, 1, -2]} intensity={0.6} color="#8f2436" />
          <Suspense fallback={null}>
            <Environment preset="night" />
            <RoseModel bloom={bloom} />
            {bloom.petals > 0.1 && (
              <Sparkles
                count={90}
                scale={[3.2, 3.2, 3.2]}
                position={[0, 0.6, 0]}
                size={2.4}
                speed={0.3}
                color="#f1d9a8"
                opacity={bloom.petals}
              />
            )}
            <ContactShadows
              position={[0, -1.42, 0]}
              opacity={0.5}
              scale={6}
              blur={2.4}
              far={2}
            />
          </Suspense>
        </Canvas>
      </div>

      <div className="relative z-10 mt-16 w-full px-6">
        <Letter show={bloom.done} />
      </div>
    </section>
  );
}
