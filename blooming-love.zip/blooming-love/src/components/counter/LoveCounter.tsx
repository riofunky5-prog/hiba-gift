"use client";

import { useEffect, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { LOVE_START_DATE } from "@/lib/constants";
import { getElapsed, pad2 } from "@/lib/utils";

function Digit({ value }: { value: string }) {
  return (
    <span className="relative inline-block h-[1.1em] w-[0.65em] overflow-hidden">
      <AnimatePresence mode="popLayout" initial={false}>
        <motion.span
          key={value}
          initial={{ y: "60%", opacity: 0 }}
          animate={{ y: "0%", opacity: 1 }}
          exit={{ y: "-60%", opacity: 0 }}
          transition={{ duration: 0.35, ease: [0.16, 1, 0.3, 1] }}
          className="absolute inset-0 flex items-center justify-center"
        >
          {value}
        </motion.span>
      </AnimatePresence>
    </span>
  );
}

function Unit({ label, value }: { label: string; value: number }) {
  const digits = pad2(value).split("");
  return (
    <div className="flex flex-col items-center gap-2">
      <div className="flex font-display text-4xl text-gold-bright sm:text-6xl">
        {digits.map((d, i) => (
          <Digit key={i} value={d} />
        ))}
      </div>
      <span className="font-body text-[11px] uppercase tracking-[0.35em] text-ivory-dim">
        {label}
      </span>
    </div>
  );
}

export default function LoveCounter() {
  const [elapsed, setElapsed] = useState(() => getElapsed(LOVE_START_DATE));

  useEffect(() => {
    const id = setInterval(() => {
      setElapsed(getElapsed(LOVE_START_DATE));
    }, 1000);
    return () => clearInterval(id);
  }, []);

  return (
    <section
      id="counter-section"
      className="relative flex w-full flex-col items-center bg-void px-6 py-28"
    >
      <motion.h2
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        transition={{ duration: 0.9 }}
        className="mb-3 text-center font-display text-4xl italic text-ivory sm:text-5xl"
      >
        Every second, counted
      </motion.h2>
      <p className="mb-14 text-center font-body text-sm text-ivory-dim">
        Since the day it all began.
      </p>

      <div className="flex flex-wrap items-center justify-center gap-8 rounded-[32px] border border-gold/20 bg-white/[0.03] px-8 py-10 backdrop-blur-md sm:gap-14 sm:px-16">
        <Unit label="Days" value={elapsed.days} />
        <span className="hidden font-display text-3xl text-gold/40 sm:block">
          :
        </span>
        <Unit label="Hours" value={elapsed.hours} />
        <span className="hidden font-display text-3xl text-gold/40 sm:block">
          :
        </span>
        <Unit label="Minutes" value={elapsed.minutes} />
        <span className="hidden font-display text-3xl text-gold/40 sm:block">
          :
        </span>
        <Unit label="Seconds" value={elapsed.seconds} />
      </div>
    </section>
  );
}
