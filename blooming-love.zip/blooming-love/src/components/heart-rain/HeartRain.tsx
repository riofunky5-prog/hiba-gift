"use client";

import { useEffect, useRef } from "react";
import { motion } from "framer-motion";

interface HeartParticle {
  x: number;
  y: number;
  size: number;
  speed: number;
  drift: number;
  angle: number;
  opacity: number;
  hue: "gold" | "wine";
}

function drawHeart(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  size: number,
  color: string,
  opacity: number
) {
  ctx.save();
  ctx.globalAlpha = opacity;
  ctx.translate(x, y);
  ctx.scale(size / 20, size / 20);
  ctx.beginPath();
  ctx.moveTo(0, 6);
  ctx.bezierCurveTo(-10, -6, -20, 4, 0, 18);
  ctx.bezierCurveTo(20, 4, 10, -6, 0, 6);
  ctx.fillStyle = color;
  ctx.fill();
  ctx.restore();
}

export default function HeartRain() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const mouseRef = useRef({ x: -1000, y: -1000 });

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    let width = (canvas.width = canvas.offsetWidth);
    let height = (canvas.height = canvas.offsetHeight);

    const particles: HeartParticle[] = Array.from({ length: 42 }, () => ({
      x: Math.random() * width,
      y: Math.random() * height,
      size: 10 + Math.random() * 16,
      speed: 0.4 + Math.random() * 0.8,
      drift: (Math.random() - 0.5) * 0.6,
      angle: Math.random() * Math.PI * 2,
      opacity: 0.25 + Math.random() * 0.5,
      hue: Math.random() > 0.5 ? "gold" : "wine",
    }));

    function handleResize() {
      if (!canvas) return;
      width = canvas.width = canvas.offsetWidth;
      height = canvas.height = canvas.offsetHeight;
    }

    function handlePointerMove(e: PointerEvent) {
      const rect = canvas!.getBoundingClientRect();
      mouseRef.current = { x: e.clientX - rect.left, y: e.clientY - rect.top };
    }

    window.addEventListener("resize", handleResize);
    canvas.addEventListener("pointermove", handlePointerMove);

    let raf: number;
    function tick() {
      ctx!.clearRect(0, 0, width, height);

      for (const p of particles) {
        p.y -= p.speed;
        p.x += p.drift + Math.sin(p.angle) * 0.3;
        p.angle += 0.01;

        const dx = p.x - mouseRef.current.x;
        const dy = p.y - mouseRef.current.y;
        const dist = Math.sqrt(dx * dx + dy * dy);
        if (dist < 90) {
          const force = (90 - dist) / 90;
          p.x += (dx / (dist || 1)) * force * 4;
          p.y += (dy / (dist || 1)) * force * 4;
        }

        if (p.y < -30) {
          p.y = height + 30;
          p.x = Math.random() * width;
        }
        if (p.x < -30) p.x = width + 30;
        if (p.x > width + 30) p.x = -30;

        drawHeart(
          ctx!,
          p.x,
          p.y,
          p.size,
          p.hue === "gold" ? "#d4af7a" : "#8f2436",
          p.opacity
        );
      }

      raf = requestAnimationFrame(tick);
    }
    raf = requestAnimationFrame(tick);

    return () => {
      cancelAnimationFrame(raf);
      window.removeEventListener("resize", handleResize);
      canvas.removeEventListener("pointermove", handlePointerMove);
    };
  }, []);

  return (
    <section
      id="heart-rain-section"
      className="relative flex h-[70vh] w-full items-center justify-center overflow-hidden bg-void"
    >
      <canvas ref={canvasRef} className="absolute inset-0 h-full w-full" />
      <div className="pointer-events-none absolute inset-0 bg-gradient-to-b from-void via-transparent to-void" />
      <motion.p
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        transition={{ duration: 1 }}
        className="relative z-10 max-w-md px-6 text-center font-script text-2xl italic text-ivory sm:text-3xl"
      >
        A thousand little hearts, for every reason you make me smile.
      </motion.p>
    </section>
  );
}
