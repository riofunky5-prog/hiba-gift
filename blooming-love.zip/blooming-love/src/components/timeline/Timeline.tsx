"use client";

import { motion } from "framer-motion";
import {
  Heart,
  Star,
  Flower2,
  Moon,
  Gem,
  Sparkles as SparkleIcon,
} from "lucide-react";
import { TIMELINE_EVENTS } from "@/lib/constants";
import type { TimelineEvent } from "@/types";

const ICONS: Record<TimelineEvent["icon"], typeof Heart> = {
  heart: Heart,
  star: Star,
  flower: Flower2,
  moon: Moon,
  ring: Gem,
  sparkle: SparkleIcon,
};

export default function Timeline() {
  return (
    <section
      id="timeline-section"
      className="relative w-full bg-void px-6 py-28 sm:px-10"
    >
      <motion.h2
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        transition={{ duration: 0.9 }}
        className="mb-20 text-center font-display text-4xl italic text-ivory sm:text-5xl"
      >
        Our story, so far
      </motion.h2>

      <div className="relative mx-auto max-w-3xl">
        <div className="absolute left-1/2 top-0 hidden h-full w-px -translate-x-1/2 bg-gradient-to-b from-gold/60 via-gold/20 to-transparent sm:block" />

        <div className="flex flex-col gap-14">
          {TIMELINE_EVENTS.map((event, index) => {
            const Icon = ICONS[event.icon];
            const fromLeft = index % 2 === 0;

            return (
              <div
                key={event.id}
                className="relative flex flex-col items-center sm:flex-row"
              >
                <div className="hidden w-1/2 sm:block sm:pr-12 sm:text-right">
                  {fromLeft && (
                    <motion.div
                      initial={{ opacity: 0, x: -60 }}
                      whileInView={{ opacity: 1, x: 0 }}
                      viewport={{ once: true, margin: "-80px" }}
                      transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
                      className="rounded-2xl border border-white/10 bg-white/[0.04] p-6 backdrop-blur-md"
                    >
                      <span className="font-body text-xs uppercase tracking-[0.3em] text-gold">
                        {event.date}
                      </span>
                      <h3 className="mt-2 font-display text-2xl italic text-ivory">
                        {event.title}
                      </h3>
                      <p className="mt-2 font-body text-sm leading-relaxed text-ivory-dim">
                        {event.description}
                      </p>
                    </motion.div>
                  )}
                </div>

                <motion.div
                  initial={{ scale: 0, opacity: 0 }}
                  whileInView={{ scale: 1, opacity: 1 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.5, delay: 0.2 }}
                  className="relative z-10 my-4 flex h-12 w-12 shrink-0 items-center justify-center rounded-full border border-gold/50 bg-void text-gold shadow-gold sm:my-0"
                >
                  <Icon size={18} />
                </motion.div>

                <div className="w-full sm:w-1/2 sm:pl-12">
                  <motion.div
                    initial={{ opacity: 0, x: fromLeft ? -60 : 60 }}
                    whileInView={{ opacity: 1, x: 0 }}
                    viewport={{ once: true, margin: "-80px" }}
                    transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
                    className={
                      fromLeft
                        ? "rounded-2xl border border-white/10 bg-white/[0.04] p-6 backdrop-blur-md sm:hidden"
                        : "rounded-2xl border border-white/10 bg-white/[0.04] p-6 backdrop-blur-md"
                    }
                  >
                    <span className="font-body text-xs uppercase tracking-[0.3em] text-gold">
                      {event.date}
                    </span>
                    <h3 className="mt-2 font-display text-2xl italic text-ivory">
                      {event.title}
                    </h3>
                    <p className="mt-2 font-body text-sm leading-relaxed text-ivory-dim">
                      {event.description}
                    </p>
                  </motion.div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
