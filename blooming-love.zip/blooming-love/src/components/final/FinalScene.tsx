"use client";

import { useCallback, useRef, useState, type MouseEvent } from "react";
import dynamic from "next/dynamic";
import { motion } from "framer-motion";
import { Heart } from "lucide-react";
import { FINAL_MESSAGE } from "@/lib/constants";
import type { FireworksHandle } from "@/components/final/Fireworks";

const NightSkyCanvas = dynamic(
  () => import("@/components/final/NightSkyCanvas"),
  { ssr: false }
);
const Fireworks = dynamic(() => import("@/components/final/Fireworks"), {
  ssr: false,
});

export default function FinalScene() {
  const [celebrating, setCelebrating] = useState(false);
  const handleRef = useRef<FireworksHandle | null>(null);

  const handleReady = useCallback((handle: FireworksHandle) => {
    handleRef.current = handle;
  }, []);

  function handleHeartClick(e: MouseEvent<HTMLButtonElement>) {
    setCelebrating(true);
    const rect = e.currentTarget.getBoundingClientRect();
    const cx = rect.left + rect.width / 2;
    const cy = rect.top + rect.height / 2;

    handleRef.current?.burst(cx, cy);
    window.setTimeout(() => {
      handleRef.current?.burst(cx - 120, cy - 60);
      handleRef.current?.burst(cx + 120, cy - 30);
    }, 300);
    window.setTimeout(() => {
      handleRef.current?.burst(cx, cy - 90);
    }, 600);
  }

  return (
    <section
      id="final-section"
      className="relative flex min-h-screen w-full items-center justify-center overflow-hidden bg-void"
    >
      <div className="absolute inset-0">
        <NightSkyCanvas />
      </div>
      <div className="absolute inset-0 bg-gradient-to-b from-void via-transparent to-void" />

      <div className="relative z-10 flex flex-col items-center px-6 text-center">
        <motion.p
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 1.1 }}
          className="font-display text-4xl italic text-ivory sm:text-6xl"
        >
          {FINAL_MESSAGE}
        </motion.p>

        <motion.button
          onClick={handleHeartClick}
          initial={{ opacity: 0, scale: 0.8 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true }}
          whileHover={{ scale: 1.1 }}
          whileTap={{ scale: 0.9 }}
          transition={{ duration: 0.8, delay: 0.4 }}
          aria-label="Click for a surprise"
          className="mt-16 flex h-20 w-20 items-center justify-center rounded-full border border-gold/50 bg-wine/40 text-gold-bright shadow-gold animate-pulse-glow sm:h-24 sm:w-24"
        >
          <Heart size={36} fill="currentColor" />
        </motion.button>

        <motion.p
          initial={{ opacity: 0 }}
          animate={celebrating ? { opacity: 1 } : { opacity: 0 }}
          transition={{ duration: 0.8 }}
          className="mt-8 font-script text-lg italic text-gold-bright"
        >
          Now and always, my heart is yours.
        </motion.p>
      </div>

      <Fireworks onReady={handleReady} />

      <footer className="absolute bottom-6 left-0 right-0 z-10 text-center font-body text-[11px] uppercase tracking-[0.3em] text-ivory-dim/60">
        Made with love, for Hiba
      </footer>
    </section>
  );
}
