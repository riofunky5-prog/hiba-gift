"use client";

import { useEffect, useRef } from "react";

interface Spark {
  x: number;
  y: number;
  vx: number;
  vy: number;
  life: number;
  maxLife: number;
  color: string;
}

const COLORS = ["#f1d9a8", "#d4af7a", "#8f2436", "#f5efe6"];

export interface FireworksHandle {
  burst: (x: number, y: number) => void;
}

export default function Fireworks({
  onReady,
}: {
  onReady: (handle: FireworksHandle) => void;
}) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const sparksRef = useRef<Spark[]>([]);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    function resize() {
      canvas!.width = window.innerWidth;
      canvas!.height = window.innerHeight;
    }
    resize();
    window.addEventListener("resize", resize);

    function burst(x: number, y: number) {
      const count = 60;
      for (let i = 0; i < count; i++) {
        const angle = (Math.PI * 2 * i) / count + Math.random() * 0.2;
        const speed = 2 + Math.random() * 4;
        sparksRef.current.push({
          x,
          y,
          vx: Math.cos(angle) * speed,
          vy: Math.sin(angle) * speed,
          life: 0,
          maxLife: 60 + Math.random() * 40,
          color: COLORS[Math.floor(Math.random() * COLORS.length)],
        });
      }
    }

    onReady({ burst });

    let raf: number;
    function tick() {
      ctx!.clearRect(0, 0, canvas!.width, canvas!.height);
      sparksRef.current = sparksRef.current.filter((s) => s.life < s.maxLife);

      for (const s of sparksRef.current) {
        s.vy += 0.035;
        s.x += s.vx;
        s.y += s.vy;
        s.life += 1;

        const alpha = 1 - s.life / s.maxLife;
        ctx!.beginPath();
        ctx!.arc(s.x, s.y, 2.4, 0, Math.PI * 2);
        ctx!.fillStyle = s.color;
        ctx!.globalAlpha = Math.max(alpha, 0);
        ctx!.fill();
      }
      ctx!.globalAlpha = 1;

      raf = requestAnimationFrame(tick);
    }
    raf = requestAnimationFrame(tick);

    return () => {
      cancelAnimationFrame(raf);
      window.removeEventListener("resize", resize);
    };
  }, [onReady]);

  return (
    <canvas
      ref={canvasRef}
      className="pointer-events-none fixed inset-0 z-[60]"
    />
  );
}
