"use client";

import { useMemo, useRef } from "react";
import { Canvas, useFrame } from "@react-three/fiber";
import { Stars } from "@react-three/drei";
import * as THREE from "three";
import { createPetalGeometry } from "@/lib/roseGeometry";
import { seededRandom } from "@/lib/utils";

function Lanterns() {
  const rand = useMemo(() => seededRandom(42), []);
  const lanterns = useMemo(
    () =>
      Array.from({ length: 14 }, () => ({
        x: (rand() - 0.5) * 12,
        z: (rand() - 0.5) * 6 - 2,
        speed: 0.15 + rand() * 0.2,
        phase: rand() * Math.PI * 2,
        scale: 0.18 + rand() * 0.12,
      })),
    [rand]
  );

  const refs = useRef<THREE.Mesh[]>([]);

  useFrame((state) => {
    const t = state.clock.elapsedTime;
    lanterns.forEach((l, i) => {
      const mesh = refs.current[i];
      if (!mesh) return;
      const y = ((t * l.speed + l.phase * 2) % 8) - 4;
      mesh.position.set(l.x + Math.sin(t * 0.2 + l.phase) * 0.4, y, l.z);
    });
  });

  return (
    <group>
      {lanterns.map((l, i) => (
        <mesh
          key={i}
          ref={(el) => {
            if (el) refs.current[i] = el;
          }}
          scale={l.scale}
        >
          <boxGeometry args={[1, 1.3, 1]} />
          <meshStandardMaterial
            color="#f1d9a8"
            emissive="#f1d9a8"
            emissiveIntensity={1.6}
            transparent
            opacity={0.85}
          />
        </mesh>
      ))}
    </group>
  );
}

function FallingPetals() {
  const geometry = useMemo(() => createPetalGeometry(), []);
  const rand = useMemo(() => seededRandom(7), []);
  const petals = useMemo(
    () =>
      Array.from({ length: 30 }, () => ({
        x: (rand() - 0.5) * 10,
        z: (rand() - 0.5) * 5,
        speed: 0.25 + rand() * 0.3,
        rotSpeed: (rand() - 0.5) * 1.2,
        phase: rand() * Math.PI * 2,
        scale: 0.08 + rand() * 0.06,
      })),
    [rand]
  );
  const refs = useRef<THREE.Mesh[]>([]);

  useFrame((state) => {
    const t = state.clock.elapsedTime;
    petals.forEach((p, i) => {
      const mesh = refs.current[i];
      if (!mesh) return;
      const y = 5 - ((t * p.speed + p.phase) % 10);
      mesh.position.set(p.x + Math.sin(t * 0.4 + p.phase) * 0.6, y, p.z);
      mesh.rotation.x = t * p.rotSpeed;
      mesh.rotation.z = t * p.rotSpeed * 0.7;
    });
  });

  return (
    <group>
      {petals.map((p, i) => (
        <mesh
          key={i}
          ref={(el) => {
            if (el) refs.current[i] = el;
          }}
          geometry={geometry}
          scale={p.scale}
        >
          <meshStandardMaterial
            color="#8f2436"
            emissive="#3a0f16"
            emissiveIntensity={0.3}
            side={THREE.DoubleSide}
          />
        </mesh>
      ))}
    </group>
  );
}

export default function NightSkyCanvas() {
  return (
    <Canvas
      camera={{ position: [0, 0, 6], fov: 50 }}
      dpr={[1, 1.75]}
      gl={{ antialias: true, alpha: true }}
    >
      <color attach="background" args={["#05050a"]} />
      <ambientLight intensity={0.25} />
      <pointLight position={[0, 2, 4]} intensity={0.6} color="#f1d9a8" />
      <Stars radius={70} depth={40} count={2600} factor={3} fade speed={0.3} />
      <Lanterns />
      <FallingPetals />
    </Canvas>
  );
}
