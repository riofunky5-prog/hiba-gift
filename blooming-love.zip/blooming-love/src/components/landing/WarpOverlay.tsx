"use client";

import { AnimatePresence, motion } from "framer-motion";

export default function WarpOverlay({ active }: { active: boolean }) {
  const streaks = Array.from({ length: 28 });

  return (
    <AnimatePresence>
      {active && (
        <motion.div
          className="pointer-events-none fixed inset-0 z-[70] overflow-hidden bg-black"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0, transition: { duration: 0.6, delay: 0.15 } }}
        >
          <motion.div
            className="absolute left-1/2 top-1/2 h-1 w-1 -translate-x-1/2 -translate-y-1/2 rounded-full bg-gold-bright"
            initial={{ scale: 0, opacity: 0.9 }}
            animate={{ scale: 140, opacity: 0 }}
            transition={{ duration: 1.1, ease: [0.16, 1, 0.3, 1] }}
            style={{ boxShadow: "0 0 120px 60px rgba(241,217,168,0.6)" }}
          />
          {streaks.map((_, i) => {
            const angle = (360 / streaks.length) * i;
            return (
              <motion.span
                key={i}
                className="absolute left-1/2 top-1/2 h-px w-1/2 origin-left bg-gradient-to-r from-gold-bright/90 via-gold/40 to-transparent"
                style={{ rotate: angle }}
                initial={{ scaleX: 0, opacity: 0 }}
                animate={{ scaleX: 1.4, opacity: [0, 1, 0] }}
                transition={{
                  duration: 0.9,
                  delay: 0.05 + (i % 6) * 0.03,
                  ease: "easeOut",
                }}
              />
            );
          })}
        </motion.div>
      )}
    </AnimatePresence>
  );
}
