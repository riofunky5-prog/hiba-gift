"use client";

import { Suspense, useRef } from "react";
import { Canvas, useFrame } from "@react-three/fiber";
import { Stars, Sparkles } from "@react-three/drei";
import * as THREE from "three";

function Moon() {
  const group = useRef<THREE.Group>(null);

  useFrame((state) => {
    if (!group.current) return;
    group.current.rotation.y += 0.0006;
    group.current.position.y =
      2.4 + Math.sin(state.clock.elapsedTime * 0.15) * 0.08;
  });

  return (
    <group ref={group} position={[3.2, 2.4, -6]}>
      {/* glow halo */}
      <mesh>
        <sphereGeometry args={[1.7, 32, 32]} />
        <meshBasicMaterial
          color="#f1d9a8"
          transparent
          opacity={0.06}
        />
      </mesh>
      <mesh>
        <sphereGeometry args={[1.3, 64, 64]} />
        <meshStandardMaterial
          color="#e8dcc4"
          emissive="#d4af7a"
          emissiveIntensity={0.35}
          roughness={0.9}
          metalness={0}
        />
      </mesh>
      <pointLight color="#f1d9a8" intensity={2.2} distance={20} decay={2} />
    </group>
  );
}

function DriftingCamera({ warping }: { warping: boolean }) {
  useFrame((state) => {
    const { camera, clock } = state;
    const t = clock.elapsedTime;
    if (!warping) {
      camera.position.x = Math.sin(t * 0.05) * 0.4;
      camera.position.y = Math.cos(t * 0.04) * 0.2;
      camera.fov = THREE.MathUtils.lerp(camera.fov, 55, 0.05);
    } else {
      camera.position.z = THREE.MathUtils.lerp(camera.position.z, -14, 0.045);
      camera.fov = THREE.MathUtils.lerp(camera.fov, 105, 0.06);
    }
    camera.updateProjectionMatrix();
  });
  return null;
}

export default function SpaceCanvas({ warping }: { warping: boolean }) {
  return (
    <Canvas
      camera={{ position: [0, 0, 5], fov: 55 }}
      dpr={[1, 1.75]}
      gl={{ antialias: true, alpha: true }}
    >
      <color attach="background" args={["#05050a"]} />
      <ambientLight intensity={0.15} />
      <Suspense fallback={null}>
        <Stars
          radius={60}
          depth={50}
          count={warping ? 2200 : 3800}
          factor={warping ? 6 : 3}
          saturation={0}
          fade
          speed={warping ? 3.4 : 0.35}
        />
        <Sparkles
          count={60}
          scale={[14, 8, 8]}
          size={2}
          speed={0.25}
          color="#f1d9a8"
          opacity={0.5}
        />
        <Moon />
      </Suspense>
      <DriftingCamera warping={warping} />
    </Canvas>
  );
}
