"use client";

import { useState } from "react";
import { motion } from "framer-motion";
import dynamic from "next/dynamic";
import { Volume2, VolumeX } from "lucide-react";
import GlowButton from "@/components/ui/GlowButton";
import WarpOverlay from "@/components/landing/WarpOverlay";
import { useJourney } from "@/components/providers/JourneyProvider";
import { useAmbientAudio } from "@/components/providers/AudioProvider";
import { SITE } from "@/lib/constants";

const SpaceCanvas = dynamic(() => import("@/components/landing/SpaceCanvas"), {
  ssr: false,
});

export default function LandingHero() {
  const { isWarping, beginJourney, endWarp } = useJourney();
  const { isPlaying, toggle } = useAmbientAudio();
  const [labelVisible, setLabelVisible] = useState(true);

  function handleOpenHeart() {
    setLabelVisible(false);
    beginJourney();

    window.setTimeout(() => {
      const target = document.getElementById("rose-section");
      target?.scrollIntoView({ behavior: "smooth" });
    }, 900);

    window.setTimeout(() => {
      endWarp();
    }, 1600);
  }

  return (
    <section
      id="landing-section"
      className="relative flex h-screen w-full items-center justify-center overflow-hidden bg-void"
    >
      <div className="absolute inset-0">
        <SpaceCanvas warping={isWarping} />
      </div>

      <div className="absolute inset-0 bg-gradient-to-b from-transparent via-transparent to-void" />

      <button
        aria-label={isPlaying ? "Pause ambient music" : "Play ambient music"}
        onClick={toggle}
        className="absolute right-6 top-6 z-20 flex h-11 w-11 items-center justify-center rounded-full border border-gold/40 bg-black/30 text-gold backdrop-blur-md transition-colors hover:border-gold hover:text-gold-bright md:right-10 md:top-10"
      >
        {isPlaying ? <Volume2 size={18} /> : <VolumeX size={18} />}
      </button>

      <div className="relative z-10 flex flex-col items-center px-6 text-center">
        <motion.p
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1, delay: 0.3 }}
          className="mb-4 font-body text-xs uppercase tracking-[0.4em] text-gold/80"
        >
          Blooming Love
        </motion.p>

        <motion.h1
          initial={{ opacity: 0, y: 24 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1.1, delay: 0.5, ease: [0.16, 1, 0.3, 1] }}
          className="font-display text-6xl italic text-ivory drop-shadow-[0_0_35px_rgba(212,175,122,0.25)] sm:text-7xl md:text-8xl"
        >
          {SITE.heroTitle} <span className="text-wine-bright">❤</span>
        </motion.h1>

        <motion.div
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1, delay: 0.9 }}
          className="mt-6 max-w-lg font-script text-lg italic text-ivory-dim sm:text-xl"
        >
          {SITE.heroSubtitleLines.map((line) => (
            <p key={line}>{line}</p>
          ))}
        </motion.div>

        {labelVisible && (
          <motion.div
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 1, delay: 1.4 }}
            className="mt-12"
          >
            <GlowButton label={SITE.ctaLabel} onClick={handleOpenHeart} />
          </motion.div>
        )}
      </div>

      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: [0.3, 0.7, 0.3] }}
        transition={{ duration: 3, repeat: Infinity, ease: "easeInOut" }}
        className="absolute bottom-8 left-1/2 z-10 -translate-x-1/2 font-body text-[10px] uppercase tracking-[0.35em] text-gold/60"
      >
        Scroll or open my heart
      </motion.div>

      <WarpOverlay active={isWarping} />
    </section>
  );
}
