import type { Metadata, Viewport } from "next";
import type { ReactNode } from "react";
import { Playfair_Display, Inter, Cormorant_Garamond } from "next/font/google";
import "./globals.css";
import SmoothScrollProvider from "@/components/providers/SmoothScrollProvider";
import { AudioProvider } from "@/components/providers/AudioProvider";
import { JourneyProvider } from "@/components/providers/JourneyProvider";

const display = Playfair_Display({
  subsets: ["latin"],
  weight: ["500", "600", "700"],
  style: ["normal", "italic"],
  variable: "--font-display",
  display: "swap",
});

const body = Inter({
  subsets: ["latin"],
  weight: ["300", "400", "500", "600"],
  variable: "--font-body",
  display: "swap",
});

const script = Cormorant_Garamond({
  subsets: ["latin"],
  weight: ["400", "500", "600"],
  style: ["italic", "normal"],
  variable: "--font-script",
  display: "swap",
});

export const metadata: Metadata = {
  title: "Blooming Love — For Hiba",
  description:
    "A private, cinematic love letter — for Hiba. Every flower blooms one day; meeting you made my heart bloom.",
  robots: {
    index: false,
    follow: false,
  },
  openGraph: {
    title: "Blooming Love — For Hiba",
    description:
      "A private, cinematic love letter — for Hiba.",
    type: "website",
  },
};

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  themeColor: "#05050a",
};

export default function RootLayout({
  children,
}: {
  children: ReactNode;
}) {
  return (
    <html lang="en" className={`${display.variable} ${body.variable} ${script.variable}`}>
      <body>
        <AudioProvider>
          <JourneyProvider>
            <SmoothScrollProvider>{children}</SmoothScrollProvider>
          </JourneyProvider>
        </AudioProvider>
      </body>
    </html>
  );
}
