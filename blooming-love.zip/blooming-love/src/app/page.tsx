import LandingHero from "@/components/landing/LandingHero";
import RoseScene from "@/components/rose/RoseScene";
import Gallery from "@/components/gallery/Gallery";
import Timeline from "@/components/timeline/Timeline";
import LoveCounter from "@/components/counter/LoveCounter";
import HeartRain from "@/components/heart-rain/HeartRain";
import FinalScene from "@/components/final/FinalScene";
import MusicPlayer from "@/components/music/MusicPlayer";

export default function HomePage() {
  return (
    <main className="relative w-full bg-void">
      <LandingHero />
      <RoseScene />
      <Gallery />
      <Timeline />
      <LoveCounter />
      <HeartRain />
      <FinalScene />
      <MusicPlayer />
    </main>
  );
}
