# Your photos go here

The gallery on the site expects these six files by default:

```
memory-1.jpg
memory-2.jpg
memory-3.jpg
memory-4.jpg
memory-5.jpg
memory-6.jpg
```

Drop your own photos of Hiba into this folder using those names, or open
`src/lib/constants.ts` and edit the `GALLERY_IMAGES` array to point at
whatever filenames and captions you like — you can have more or fewer
than six.

For best results:
- Use photos at least 1200px on the longer side.
- Roughly portrait or 4:5 photos crop the most gracefully into the cards.
- JPG or WebP keep file size (and load time) down; Next.js will still
  optimize whatever format you use.

This folder intentionally ships empty of any stock or placeholder
imagery — the site is meant to hold real memories, not filler.
