# Your song goes here

Add one audio file named exactly:

```
music.mp3
```

to this folder. The ambient music button on the landing scene and the
glassmorphism player in the bottom-right corner both control this same
file (`/public/music/music.mp3`).

To use a different filename or format (e.g. `.ogg` for smaller size),
update `AMBIENT_TRACK.src` in `src/lib/constants.ts`.

Please make sure you have the right to use whatever track you choose
(a personal recording, a royalty-free track, or a properly licensed
song) since this project is meant to be shared privately or deployed
publicly.
